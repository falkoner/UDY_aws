CloudFront end point: http://d31ecxbxp1juu4.cloudfront.net/index.html
S3 bucket end point: http://udacity-website-af.s3-website-us-west-1.amazonaws.com

